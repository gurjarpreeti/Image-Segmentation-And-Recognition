import pymysql
import tkinter as tk
from tkinter import ttk, BOTTOM

r=tk.Tk()

r.rirle("crminal detels")
r.geometry("600x300")
connect = pymysql.connect(host="localhost",
                     user="root",
                     password="",
                     database="criminaldb")
conn = connect.cursor()
conn.execute("SELECT * FROM criminaldata ")

tree=ttk.treeview(r)
tree['show']='headings'

s=ttk.Style(r)
s.theme_use('clam')

s.configure(".",font=('Helvetica',11))
s.configure("Treeview.Heading",foreground='red',font=('Helvetica',11,"bold"))

#define number of colums
tree["columns"]=("Name", "Father's Name", "Mother's Name", "Gender", "DOB(yyyy-mm-dd)", "Blood Group",
                    "Identification Mark", "Nationality", "Religion", "Crimes Done")
#assin the width ,minwidth and anchor to the respective
tree.column("id",width=50,minwidth=50,anchor=tk.CENTER)
tree.column("Name",width=50,minwidth=50,anchor=tk.CENTER)
tree.column("Father's Name",width=50,minwidth=50,anchor=tk.CENTER)
tree.column("Mother's Name",width=50,minwidth=50,anchor=tk.CENTER)
tree.column("Gender",width=50,minwidth=50,anchor=tk.CENTER)
tree.column("DOB(yyyy-mm-dd)",width=50,minwidth=50,anchor=tk.CENTER)
tree.column("Blood Group",width=50,minwidth=50,anchor=tk.CENTER)
tree.column("Identification Mark",width=50,minwidth=50,anchor=tk.CENTER)
tree.column("Nationality",width=50,minwidth=50,anchor=tk.CENTER)
tree.column("Religion",width=50,minwidth=50,anchor=tk.CENTER)
tree.column("Crimes Done",width=50,minwidth=50,anchor=tk.CENTER)

#assign the heading name
tree.heading("Name",text="s_id",anchor=tk.CENTER)
tree.heading("Father's Name",text="s_id",anchor=tk.CENTER)
tree.heading("Mother's Name",text="Mother's Name",anchor=tk.CENTER)
tree.heading("Gender",text="Gender",anchor=tk.CENTER)
tree.heading("DOB(yyyy-mm-dd)",text="DOB(yyyy-mm-dd)",anchor=tk.CENTER)
tree.heading("Blood Group",text="Blood Group",anchor=tk.CENTER)
tree.heading("Identification Mark",text="Identification Mark",anchor=tk.CENTER)
tree.heading("Nationality",text="Nationality",anchor=tk.CENTER)
tree.heading("Religion",text="Religion",anchor=tk.CENTER)
tree.heading("Crimes Done",text="Crimes Done",anchor=tk.CENTER)
i=0
for ro in conn:
    tree.insert('.'i,text="",values(ro[1],ro[2],ro[3],ro[4],ro[5],ro[6],ro[7],ro[8],ro[9],ro[10]))
    i=i+1
hsb=ttk.Scrollbar(r,orient="horizontal")
hsb.configure(command=tree.xview)
tree.configure(xscrollcommand=hsb.set)
hsb.pack(fill=x,side=BOTTOM)

tree.pack()
r.mainloop()